package com.project.question2;

class MaximumDiffrence  
{ 

    int maxDiff(int arr[], int arr_size)  
    { 
        int max_diff = arr[1] - arr[0]; 
        int i, j; 
        for (i = 0; i < arr_size; i++)  
        { 
            for (j = i + 1; j < arr_size; j++)  
            { 
                if (arr[j] - arr[i] > max_diff) 
                    max_diff = arr[j] - arr[i]; 
            } 
        } 
        return max_diff; 
    } 
  
    /* Driver program to test above functions */
    public static void main(String[] args)  
    { 
        MaximumDiffrence maxdif = new MaximumDiffrence(); 
        int arr[] = {7,2,3,10,2,4,8,1}; //case0
        System.out.println("Maximum differnce is " +   maxdif.maxDiff(arr, 7));
        int arr1[] = {6,7,9,5,6,3,2};//case1
        System.out.println("Maximum differnce is " +   maxdif.maxDiff(arr1, 6));
    } 
} 
  