package com.project.question1;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SearchResult {

    @JsonProperty("page")
    private String page;

    @JsonProperty("per_page")
    private String per_page;

    @JsonProperty("total")
    private String total;

    @JsonProperty("total_pages")
    private String total_pages;

    @JsonProperty("data")
    private List<MovieTitle> movieTitles;

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public String getPer_page() {
        return per_page;
    }

    public void setPer_page(String per_page) {
        this.per_page = per_page;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(String total_pages) {
        this.total_pages = total_pages;
    }

    public List<MovieTitle> getMovieTitles() {
        return movieTitles;
    }

    public void setMovieTitles(List<MovieTitle> movieTitles) {
        this.movieTitles = movieTitles;
    }

}
